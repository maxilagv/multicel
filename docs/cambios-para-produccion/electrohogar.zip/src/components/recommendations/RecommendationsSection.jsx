import { useMemo, useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { products } from "../../lib/storeData";
import { getFavorites, subscribeToFavorites } from "../../lib/favoritesStore";
import { getBrowsingHistory, subscribeToBrowsingHistory } from "../../lib/browsingHistoryStore";
import ProductCard from "../products/ProductCard";

export default function RecommendationsSection({ excludeIds = [] }) {
  const [, setTick] = useState(0);
  const refresh = () => setTick((t) => t + 1);

  useEffect(() => {
    const u1 = subscribeToFavorites(refresh);
    const u2 = subscribeToBrowsingHistory(refresh);
    return () => { u1(); u2(); };
  }, []);

  const recommended = useMemo(() => {
    const favorites = getFavorites();
    const history = getBrowsingHistory();

    // Collect categories and brands from signals
    const favCategories = favorites.map((p) => p.category);
    const historyProducts = history
      .map((id) => products.find((p) => p.id === id))
      .filter(Boolean);
    const historyCategories = historyProducts.map((p) => p.category);
    const historyBrands = historyProducts.map((p) => p.brand);

    const allCategories = [...favCategories, ...historyCategories];
    const allBrands = historyBrands;

    const exclude = new Set([
      ...excludeIds,
      ...favorites.map((p) => p.id),
      ...history,
    ]);

    if (allCategories.length === 0 && allBrands.length === 0) return [];

    // Score each product
    const scored = products
      .filter((p) => !exclude.has(p.id))
      .map((p) => {
        let score = 0;
        allCategories.forEach((c) => { if (p.category === c) score += 2; });
        allBrands.forEach((b) => { if (p.brand === b) score += 1; });
        score += p.rating * 0.5;
        if (p.featured) score += 1;
        return { product: p, score };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 6)
      .map((s) => s.product);

    return scored;
  }, [excludeIds]);

  if (recommended.length === 0) return null;

  return (
    <section className="py-10">
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="w-5 h-5 text-primary" />
        <h2 className="font-space text-xl sm:text-2xl font-bold">
          Te podría interesar
        </h2>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {recommended.map((product, idx) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
          >
            <ProductCard product={product} />
          </motion.div>
        ))}
      </div>
    </section>
  );
}
