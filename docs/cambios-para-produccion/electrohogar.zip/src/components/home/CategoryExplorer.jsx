import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { categories } from "../../lib/storeData";

export default function CategoryExplorer() {
  return (
    <section className="py-20 lg:py-28 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <p className="text-primary font-medium text-sm mb-2 tracking-wide uppercase">
            Navega por sección
          </p>
          <h2 className="font-space text-3xl sm:text-4xl font-bold tracking-tight">
            Explora por Categoría
          </h2>
          <p className="text-muted-foreground mt-3 max-w-md mx-auto">
            Encuentra exactamente lo que buscas navegando nuestras categorías cuidadosamente organizadas.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
          {categories.map((cat, idx) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.06 }}
            >
              <Link
                to={`/productos?category=${cat.id}`}
                className="group relative block rounded-2xl overflow-hidden aspect-square"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-6">
                  <div className="flex items-end justify-between">
                    <div>
                      <h3 className="text-white font-space font-semibold text-sm sm:text-xl">
                        {cat.name}
                      </h3>
                      <p className="text-white/60 text-xs sm:text-sm mt-0.5">
                        {cat.count} productos
                      </p>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                      <ArrowUpRight className="w-4 h-4 text-white group-hover:text-black transition-colors" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
