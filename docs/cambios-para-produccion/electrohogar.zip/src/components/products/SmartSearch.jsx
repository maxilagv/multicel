import { useState, useRef, useEffect } from "react";
import { Search, X, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { products, formatPrice } from "../../lib/storeData";
import { motion, AnimatePresence } from "framer-motion";

export default function SmartSearch({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const suggestions = value.trim().length >= 2
    ? products
        .filter((p) =>
          p.name.toLowerCase().includes(value.toLowerCase()) ||
          p.brand.toLowerCase().includes(value.toLowerCase())
        )
        .slice(0, 6)
    : [];

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div ref={ref} className="relative flex-1">
      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
      <input
        type="text"
        placeholder="Buscar productos, marcas..."
        value={value}
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        className="w-full h-11 pl-10 pr-10 rounded-xl border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
      />
      {value && (
        <button
          onClick={() => { onChange(""); setOpen(false); }}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      <AnimatePresence>
        {open && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 mt-2 z-50 bg-card border border-border rounded-xl shadow-2xl overflow-hidden"
          >
            <p className="px-4 py-2 text-[11px] text-muted-foreground uppercase tracking-wider font-medium border-b border-border/50">
              Sugerencias
            </p>
            {suggestions.map((product) => (
              <Link
                key={product.id}
                to={`/producto/${product.id}`}
                onClick={() => { setOpen(false); onChange(""); }}
                className="flex items-center gap-3 px-4 py-3 hover:bg-secondary/50 transition-colors group"
              >
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-10 h-10 rounded-lg object-cover bg-secondary flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                    {product.name}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-muted-foreground">{product.brand}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      {product.rating}
                    </span>
                  </div>
                </div>
                <span className="text-sm font-bold font-space text-primary flex-shrink-0">
                  {formatPrice(product.price)}
                </span>
              </Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
