import { useState, useEffect } from "react";
import { Star, ThumbsUp, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";

function StarPicker({ value, onChange }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          onClick={() => onChange(s)}
          onMouseEnter={() => setHovered(s)}
          onMouseLeave={() => setHovered(0)}
        >
          <Star
            className={`w-7 h-7 transition-colors ${
              s <= (hovered || value)
                ? "fill-yellow-400 text-yellow-400"
                : "text-border"
            }`}
          />
        </button>
      ))}
    </div>
  );
}

export default function ReviewsSection({ productId }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ author_name: "", rating: 0, title: "", body: "" });

  const loadReviews = () => {
    base44.entities.Review.filter({ product_id: productId }, "-created_date", 20).then((data) => {
      setReviews(data);
      setLoading(false);
    });
  };

  useEffect(() => {
    loadReviews();
  }, [productId]);

  const avgRating = reviews.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.rating || !form.body || !form.author_name) return;
    setSubmitting(true);
    await base44.entities.Review.create({ ...form, product_id: productId, verified: false });
    setSubmitting(false);
    setSubmitted(true);
    setShowForm(false);
    setForm({ author_name: "", rating: 0, title: "", body: "" });
    loadReviews();
  };

  return (
    <section className="mt-16 pt-10 border-t border-border/50">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="font-space text-2xl font-bold">Reseñas de clientes</h2>
          {avgRating && (
            <div className="flex items-center gap-2 mt-2">
              <span className="text-4xl font-bold font-space">{avgRating}</span>
              <div>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-4 h-4 ${
                        s <= Math.round(Number(avgRating))
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-border"
                      }`}
                    />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {reviews.length} reseña{reviews.length !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
          )}
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          variant={showForm ? "outline" : "default"}
          className="rounded-xl"
        >
          {showForm ? "Cancelar" : "Escribir reseña"}
        </Button>
      </div>

      {/* Form */}
      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-secondary/30 rounded-2xl p-6 mb-8 space-y-4 overflow-hidden"
          >
            <h3 className="font-space font-semibold">Tu reseña</h3>
            <div>
              <label className="text-sm font-medium mb-2 block">Puntuación *</label>
              <StarPicker value={form.rating} onChange={(v) => setForm({ ...form, rating: v })} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Tu nombre *</label>
                <input
                  type="text"
                  value={form.author_name}
                  onChange={(e) => setForm({ ...form, author_name: e.target.value })}
                  placeholder="Juan García"
                  className="w-full h-10 px-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Título</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Resumen de tu opinión"
                  className="w-full h-10 px-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Reseña *</label>
              <textarea
                rows={4}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="Cuéntanos tu experiencia con el producto..."
                className="w-full px-3 py-2.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
              />
            </div>
            <Button type="submit" disabled={submitting} className="rounded-xl">
              {submitting ? "Publicando..." : "Publicar reseña"}
            </Button>
          </motion.form>
        )}
      </AnimatePresence>

      {submitted && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-green-500/10 text-green-600 mb-6"
        >
          <CheckCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">¡Gracias! Tu reseña fue publicada.</p>
        </motion.div>
      )}

      {/* Reviews list */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="h-28 rounded-2xl bg-secondary animate-pulse" />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Star className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="font-medium">Aún no hay reseñas</p>
          <p className="text-sm mt-1">¡Sé el primero en opinar sobre este producto!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review, idx) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.04 }}
              className="bg-card rounded-2xl border border-border/50 p-6"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                    {review.author_name?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-sm">{review.author_name}</p>
                      {review.verified && (
                        <span className="flex items-center gap-1 text-xs text-green-600">
                          <CheckCircle className="w-3 h-3" /> Verificado
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(review.created_date).toLocaleDateString("es-AR", {
                        day: "2-digit", month: "long", year: "numeric",
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex gap-0.5 flex-shrink-0">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-3.5 h-3.5 ${
                        s <= review.rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-border"
                      }`}
                    />
                  ))}
                </div>
              </div>
              {review.title && (
                <p className="font-semibold mt-3">{review.title}</p>
              )}
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                {review.body}
              </p>
            </motion.div>
          ))}
        </div>
      )}
    </section>
  );
}
