import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Star, ShoppingCart, Heart, Truck, ChevronLeft, ChevronRight, GitCompare } from "lucide-react";
import { addToComparator, removeFromComparator, isInComparator, subscribeToComparator } from "../../lib/comparatorStore";
import { toggleFavorite, isFavorite, subscribeToFavorites } from "../../lib/favoritesStore";
import { motion } from "framer-motion";
import { formatPrice } from "../../lib/storeData";
import useCart from "../../hooks/useCart";
import { useToast } from "@/components/ui/use-toast";

export default function ProductCard({ product }) {
  const [currentImage, setCurrentImage] = useState(0);
  const [inComparator, setInComparator] = useState(() => isInComparator(product.id));
  const [liked, setLiked] = useState(() => isFavorite(product.id));

  useEffect(() => {
    return subscribeToComparator(() => setInComparator(isInComparator(product.id)));
  }, [product.id]);

  useEffect(() => {
    return subscribeToFavorites(() => setLiked(isFavorite(product.id)));
  }, [product.id]);

  const handleLike = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(product);
  };

  const handleCompare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (inComparator) removeFromComparator(product.id);
    else addToComparator(product);
  };
  const { addToCart } = useCart();
  const { toast } = useToast();

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    toast({
      title: "Agregado al carrito",
      description: product.name,
    });
  };

  const nextImage = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImage((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImage((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  return (
    <Link to={`/producto/${product.id}`} className="group block active:scale-[0.98] transition-transform">
      <div className="bg-card rounded-2xl border border-border/50 overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-1">
        {/* Image container */}
        <div className="relative aspect-square overflow-hidden bg-secondary/30">
          <img
            src={product.images[currentImage]}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />

          {/* Image navigation arrows */}
          {product.images.length > 1 && (
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={prevImage}
                className="w-8 h-8 rounded-full bg-white/90 shadow-lg flex items-center justify-center hover:bg-white transition-colors"
              >
                <ChevronLeft className="w-4 h-4 text-foreground" />
              </button>
              <button
                onClick={nextImage}
                className="w-8 h-8 rounded-full bg-white/90 shadow-lg flex items-center justify-center hover:bg-white transition-colors"
              >
                <ChevronRight className="w-4 h-4 text-foreground" />
              </button>
            </div>
          )}

          {/* Image dots */}
          {product.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {product.images.map((_, idx) => (
                <span
                  key={idx}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    idx === currentImage
                      ? "bg-white w-4"
                      : "bg-white/50"
                  }`}
                />
              ))}
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-2 left-2 sm:top-3 sm:left-3 flex flex-col gap-1.5">
            {product.badge && (
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 bg-primary text-primary-foreground text-[10px] sm:text-xs font-semibold rounded-lg">
                {product.badge}
              </span>
            )}
            {discount > 0 && (
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 bg-green-500 text-white text-[10px] sm:text-xs font-semibold rounded-lg">
                -{discount}%
              </span>
            )}
          </div>

          {/* Like button */}
          <button
            onClick={handleLike}
            className="absolute top-2 right-2 sm:top-3 sm:right-3 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-all shadow-sm"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${
                liked ? "fill-red-500 text-red-500" : "text-foreground/60"
              }`}
            />
          </button>
        </div>

        {/* Content */}
        <div className="p-3 sm:p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">
            {product.brand}
          </p>
          <h3 className="font-medium mt-1 text-sm leading-tight line-clamp-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-2">
            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span className="text-xs font-medium">{product.rating}</span>
            <span className="text-xs text-muted-foreground">
              ({product.reviews.toLocaleString()})
            </span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-2 mt-3">
            <span className="text-lg font-bold font-space text-foreground">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          {/* Free shipping + Add to cart */}
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
            {product.freeShipping && (
              <div className="flex items-center gap-1 text-green-600 text-xs font-medium">
                <Truck className="w-3.5 h-3.5" />
                Envío gratis
              </div>
            )}
            <div className="ml-auto flex items-center gap-1.5">
              <button
                onClick={handleCompare}
                title="Comparar"
                className={`flex items-center justify-center w-7 h-7 rounded-lg border transition-colors ${
                  inComparator
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                }`}
              >
                <GitCompare className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleAddToCart}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                Agregar
              </button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
