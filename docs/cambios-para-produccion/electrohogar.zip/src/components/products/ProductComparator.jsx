import { useState, useEffect } from "react";
import { X, GitCompare, ChevronDown, ChevronUp, Star } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { formatPrice } from "../../lib/storeData";
import {
  getComparator,
  removeFromComparator,
  clearComparator,
  subscribeToComparator,
} from "../../lib/comparatorStore";

export default function ProductComparator() {
  const [items, setItems] = useState(getComparator());
  const [expanded, setExpanded] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    return subscribeToComparator(() => setItems([...getComparator()]));
  }, []);

  if (items.length === 0) return null;

  const specs = items.length > 0
    ? Object.keys(items[0].specs || {})
    : [];

  return (
    <>
      {/* Floating bar */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border shadow-2xl"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-semibold">
              <GitCompare className="w-4 h-4 text-primary" />
              <span>Comparar ({items.length}/3)</span>
            </div>

            <div className="flex-1 flex items-center gap-3 overflow-x-auto">
              {items.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center gap-2 bg-secondary/50 rounded-xl px-3 py-1.5 flex-shrink-0"
                >
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-8 h-8 rounded-lg object-cover"
                  />
                  <span className="text-xs font-medium max-w-24 truncate">{product.name}</span>
                  <button
                    onClick={() => removeFromComparator(product.id)}
                    className="text-muted-foreground hover:text-foreground ml-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {Array.from({ length: 3 - items.length }).map((_, i) => (
                <div
                  key={i}
                  className="w-32 h-9 rounded-xl border-2 border-dashed border-border flex items-center justify-center text-xs text-muted-foreground flex-shrink-0"
                >
                  + Agregar
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              {items.length >= 2 && (
                <button
                  onClick={() => setShowModal(true)}
                  className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-xl hover:bg-primary/90 transition-colors"
                >
                  Comparar
                </button>
              )}
              <button
                onClick={clearComparator}
                className="px-3 py-2 text-xs text-muted-foreground hover:text-foreground border border-border rounded-xl transition-colors"
              >
                Limpiar
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Comparison modal */}
      <AnimatePresence>
        {showModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-4 sm:inset-10 z-[70] bg-card rounded-2xl border border-border shadow-2xl overflow-auto"
            >
              <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between">
                <h2 className="font-space text-xl font-bold flex items-center gap-2">
                  <GitCompare className="w-5 h-5 text-primary" />
                  Comparar Productos
                </h2>
                <button onClick={() => setShowModal(false)}>
                  <X className="w-5 h-5 text-muted-foreground hover:text-foreground" />
                </button>
              </div>

              <div className="p-6 overflow-x-auto">
                <table className="w-full min-w-[500px]">
                  <thead>
                    <tr>
                      <th className="text-left text-sm font-medium text-muted-foreground pb-6 w-36">
                        Característica
                      </th>
                      {items.map((product) => (
                        <th key={product.id} className="pb-6 px-4 text-center">
                          <div className="space-y-2">
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-20 h-20 object-cover rounded-xl mx-auto bg-secondary"
                            />
                            <p className="font-semibold text-sm leading-tight">{product.name}</p>
                            <p className="text-xs text-muted-foreground">{product.brand}</p>
                            <p className="font-bold text-primary font-space">{formatPrice(product.price)}</p>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {/* Rating */}
                    <tr>
                      <td className="py-3 text-sm text-muted-foreground">Calificación</td>
                      {items.map((product) => (
                        <td key={product.id} className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm font-medium">{product.rating}</span>
                          </div>
                        </td>
                      ))}
                    </tr>
                    {/* Price */}
                    <tr>
                      <td className="py-3 text-sm text-muted-foreground">Precio</td>
                      {items.map((product) => (
                        <td key={product.id} className="py-3 px-4 text-center">
                          <span className="font-bold font-space text-primary">{formatPrice(product.price)}</span>
                        </td>
                      ))}
                    </tr>
                    {/* Specs */}
                    {specs.map((spec) => (
                      <tr key={spec}>
                        <td className="py-3 text-sm text-muted-foreground capitalize">{spec}</td>
                        {items.map((product) => (
                          <td key={product.id} className="py-3 px-4 text-center text-sm">
                            {product.specs?.[spec] ?? "—"}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
