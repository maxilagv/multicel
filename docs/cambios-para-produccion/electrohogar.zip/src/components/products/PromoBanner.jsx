import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const slides = [
  {
    id: 1,
    bg: "from-slate-900 via-slate-800 to-slate-900",
    label: "Del 04/04 al 20/04",
    brand: "Samsung",
    brandColor: "#1428A0",
    headline: "Galaxy Week",
    subline: "Smartphones y tablets",
    discount: "25% OFF",
    cuotas: "12 SIN INTERÉS",
    image: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600&q=80",
    link: "/productos?category=smartphones",
    accent: "#1428A0",
  },
  {
    id: 2,
    bg: "from-zinc-900 via-zinc-800 to-zinc-900",
    label: "Oferta limitada",
    brand: "Apple",
    brandColor: "#ffffff",
    headline: "AirPods & MacBook",
    subline: "Accesorios y notebooks",
    discount: "20% OFF",
    cuotas: "9 SIN INTERÉS",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&q=80",
    link: "/productos?category=laptops",
    accent: "#A78BFA",
  },
  {
    id: 3,
    bg: "from-blue-950 via-blue-900 to-blue-950",
    label: "Esta semana",
    brand: "Sony",
    brandColor: "#ffffff",
    headline: "Audio Premium",
    subline: "Auriculares y parlantes",
    discount: "30% OFF",
    cuotas: "6 SIN INTERÉS",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80",
    link: "/productos?category=audio",
    accent: "#38BDF8",
  },
  {
    id: 4,
    bg: "from-emerald-950 via-emerald-900 to-emerald-950",
    label: "Nuevo ingreso",
    brand: "LG",
    brandColor: "#ffffff",
    headline: "Smart TVs 4K",
    subline: "Televisores de última generación",
    discount: "15% OFF",
    cuotas: "18 SIN INTERÉS",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f4834f?w=600&q=80",
    link: "/productos?category=televisores",
    accent: "#34D399",
  },
];

export default function PromoBanner() {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);

  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const go = (idx) => {
    setDirection(idx > current ? 1 : -1);
    setCurrent(idx);
  };

  const prev = () => {
    setDirection(-1);
    setCurrent((c) => (c - 1 + slides.length) % slides.length);
  };

  const next = () => {
    setDirection(1);
    setCurrent((c) => (c + 1) % slides.length);
  };

  const slide = slides[current];

  const variants = {
    enter: (d) => ({ x: d > 0 ? "100%" : "-100%", opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d) => ({ x: d > 0 ? "-100%" : "100%", opacity: 0 }),
  };

  return (
    <div className="relative w-full overflow-hidden rounded-2xl" style={{ height: "280px" }}>
      <AnimatePresence initial={false} custom={direction} mode="popLayout">
        <motion.div
          key={slide.id}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ duration: 0.45, ease: "easeInOut" }}
          className={`absolute inset-0 bg-gradient-to-r ${slide.bg} flex items-center`}
        >
          {/* Left content */}
          <div className="flex-1 px-8 md:px-14 z-10 space-y-3">
            <span className="text-white/50 text-xs font-medium uppercase tracking-widest">
              {slide.label}
            </span>
            <p
              className="font-space text-4xl md:text-5xl font-black tracking-tight leading-none"
              style={{ color: slide.accent }}
            >
              {slide.brand}
            </p>
            <div>
              <h2 className="text-white font-space text-2xl md:text-3xl font-bold leading-tight">
                {slide.headline}
              </h2>
              <p className="text-white/60 text-sm mt-1">{slide.subline}</p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <div className="bg-white rounded-xl px-4 py-2 text-center">
                <p className="text-xs text-gray-500 font-medium">HASTA</p>
                <p className="text-2xl font-black" style={{ color: slide.accent }}>
                  {slide.discount}
                </p>
              </div>
              <div className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-center">
                <p className="text-xs text-white/50 font-medium">HASTA</p>
                <p className="text-lg font-black text-white">{slide.cuotas}</p>
              </div>
            </div>

            <Link
              to={slide.link}
              className="inline-block mt-1 text-xs font-semibold px-5 py-2.5 rounded-lg text-white border border-white/30 hover:bg-white/10 transition-colors"
            >
              Ver ofertas →
            </Link>
          </div>

          {/* Right image */}
          <div className="hidden sm:block w-64 md:w-80 h-full relative flex-shrink-0">
            <div
              className="absolute inset-0"
              style={{
                background: `radial-gradient(ellipse at center, ${slide.accent}22 0%, transparent 70%)`,
              }}
            />
            <img
              src={slide.image}
              alt={slide.headline}
              className="absolute inset-0 w-full h-full object-cover object-center opacity-80 mix-blend-luminosity"
            />
          </div>

          {/* Subtle decorative glow */}
          <div
            className="absolute top-0 left-1/3 w-96 h-96 rounded-full blur-3xl opacity-10 pointer-events-none"
            style={{ background: slide.accent }}
          />
        </motion.div>
      </AnimatePresence>

      {/* Arrows */}
      <button
        onClick={prev}
        className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center text-white transition-colors"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={next}
        className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center text-white transition-colors"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => go(idx)}
            className={`rounded-full transition-all duration-300 ${
              idx === current ? "w-6 h-2 bg-white" : "w-2 h-2 bg-white/40"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
