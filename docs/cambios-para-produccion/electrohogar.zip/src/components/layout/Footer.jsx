import { Link } from "react-router-dom";
import { Zap, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-space font-bold text-xl">TechVault</span>
            </div>
            <p className="text-sm opacity-60 leading-relaxed">
              Tu destino para la mejor tecnología. Productos premium, precios
              competitivos y envío a todo el país.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-space font-semibold mb-4">Navegación</h4>
            <ul className="space-y-3 text-sm opacity-60">
              <li><Link to="/" className="hover:opacity-100 transition-opacity">Inicio</Link></li>
              <li><Link to="/productos" className="hover:opacity-100 transition-opacity">Productos</Link></li>
              <li><Link to="/contacto" className="hover:opacity-100 transition-opacity">Contacto</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-space font-semibold mb-4">Categorías</h4>
            <ul className="space-y-3 text-sm opacity-60">
              <li><Link to="/productos?category=smartphones" className="hover:opacity-100 transition-opacity">Smartphones</Link></li>
              <li><Link to="/productos?category=laptops" className="hover:opacity-100 transition-opacity">Laptops</Link></li>
              <li><Link to="/productos?category=audio" className="hover:opacity-100 transition-opacity">Audio</Link></li>
              <li><Link to="/productos?category=gaming" className="hover:opacity-100 transition-opacity">Gaming</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-space font-semibold mb-4">Contacto</h4>
            <ul className="space-y-3 text-sm opacity-60">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" /> info@techvault.com
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" /> +54 11 1234-5678
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4" /> Buenos Aires, Argentina
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/10 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm opacity-40">
            © 2026 TechVault. Todos los derechos reservados.
          </p>
          <div className="flex gap-6 text-sm opacity-40">
            <span className="hover:opacity-100 cursor-pointer transition-opacity">Privacidad</span>
            <span className="hover:opacity-100 cursor-pointer transition-opacity">Términos</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
