import { useState, useEffect } from "react";
import { Heart, X, ShoppingCart, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { getFavorites, removeFavorite, subscribeToFavorites } from "../../lib/favoritesStore";
import { formatPrice } from "../../lib/storeData";
import useCart from "../../hooks/useCart";
import { useToast } from "@/components/ui/use-toast";

export default function FavoritesDrawer({ open, onClose }) {
  const [favorites, setFavorites] = useState(getFavorites());
  const { addToCart } = useCart();
  const { toast } = useToast();

  useEffect(() => {
    return subscribeToFavorites(() => setFavorites([...getFavorites()]));
  }, []);

  const handleAddToCart = (product) => {
    addToCart(product);
    toast({ title: "Agregado al carrito", description: product.name });
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full max-w-sm bg-card border-l border-border flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500 fill-red-500" />
                <h2 className="font-space font-bold text-lg">Mis Favoritos</h2>
                {favorites.length > 0 && (
                  <span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
                    {favorites.length}
                  </span>
                )}
              </div>
              <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
              {favorites.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 px-6 text-center">
                  <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center">
                    <Heart className="w-10 h-10 text-red-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-lg">Sin favoritos aún</p>
                    <p className="text-muted-foreground text-sm mt-1">
                      Presioná el ❤️ en cualquier producto para guardarlo acá.
                    </p>
                  </div>
                  <Link
                    to="/productos"
                    onClick={onClose}
                    className="text-primary text-sm font-medium hover:underline"
                  >
                    Explorar productos →
                  </Link>
                </div>
              ) : (
                <div className="divide-y divide-border/50">
                  {favorites.map((product) => (
                    <div key={product.id} className="flex gap-4 p-4 hover:bg-secondary/30 transition-colors">
                      <Link to={`/producto/${product.id}`} onClick={onClose} className="flex-shrink-0">
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-20 h-20 rounded-xl object-cover bg-secondary"
                        />
                      </Link>
                      <div className="flex-1 min-w-0 space-y-1">
                        <Link
                          to={`/producto/${product.id}`}
                          onClick={onClose}
                          className="text-sm font-medium line-clamp-2 hover:text-primary transition-colors"
                        >
                          {product.name}
                        </Link>
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                        <p className="font-bold font-space text-primary">{formatPrice(product.price)}</p>
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => handleAddToCart(product)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-colors"
                          >
                            <ShoppingCart className="w-3.5 h-3.5" />
                            Agregar
                          </button>
                          <button
                            onClick={() => removeFavorite(product.id)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
