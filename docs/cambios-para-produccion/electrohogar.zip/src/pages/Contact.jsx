import { Mail, Phone, MapPin, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

const contactInfo = [
  {
    icon: Mail,
    title: "Email",
    detail: "info@techvault.com",
    sub: "Respondemos en 24hs",
  },
  {
    icon: Phone,
    title: "Teléfono",
    detail: "+54 11 1234-5678",
    sub: "Lun a Vie 9:00 - 18:00",
  },
  {
    icon: MapPin,
    title: "Dirección",
    detail: "Av. Corrientes 1234",
    sub: "Buenos Aires, Argentina",
  },
  {
    icon: Clock,
    title: "Horario",
    detail: "Lun - Vie: 9:00 - 18:00",
    sub: "Sáb: 10:00 - 14:00",
  },
];

export default function Contact() {
  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 lg:py-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <p className="text-primary font-medium text-sm mb-2 tracking-wide uppercase">
          Estamos para ayudarte
        </p>
        <h1 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
          Contacto
        </h1>
        <p className="text-muted-foreground mt-4 max-w-lg mx-auto text-lg">
          ¿Tienes preguntas? No dudes en contactarnos. Nuestro equipo está listo para asistirte.
        </p>
      </motion.div>

      {/* Contact cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-10 sm:mb-16">
        {contactInfo.map((item, idx) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-card rounded-2xl border border-border/50 p-6 text-center hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-space font-semibold text-lg">{item.title}</h3>
              <p className="font-medium mt-2">{item.detail}</p>
              <p className="text-sm text-muted-foreground mt-1">{item.sub}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Map + Form */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Map */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="rounded-2xl overflow-hidden border border-border/50 h-[400px] lg:h-auto"
        >
          <MapContainer
            center={[-34.6037, -58.3816]}
            zoom={14}
            scrollWheelZoom={false}
            className="w-full h-full min-h-[400px]"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={[-34.6037, -58.3816]}>
              <Popup>
                <strong>TechVault</strong>
                <br />
                Av. Corrientes 1234, Buenos Aires
              </Popup>
            </Marker>
          </MapContainer>
        </motion.div>

        {/* Contact form */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-2xl border border-border/50 p-8"
        >
          <h2 className="font-space text-2xl font-bold mb-6">
            Envíanos un mensaje
          </h2>
          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="text-sm font-medium mb-2 block">Nombre</label>
                <input
                  type="text"
                  placeholder="Tu nombre"
                  className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Email</label>
                <input
                  type="email"
                  placeholder="tu@email.com"
                  className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Asunto</label>
              <input
                type="text"
                placeholder="¿En qué podemos ayudarte?"
                className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Mensaje</label>
              <textarea
                rows={5}
                placeholder="Escribe tu mensaje aquí..."
                className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all resize-none"
              />
            </div>
            <Button className="w-full h-12 text-base rounded-xl font-semibold gap-2">
              <Send className="w-4 h-4" />
              Enviar Mensaje
            </Button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
