import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Package, ChevronRight, ShoppingBag, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { formatPrice } from "../lib/storeData";

const statusConfig = {
  pending: { label: "Pendiente", color: "bg-yellow-500/10 text-yellow-600" },
  processing: { label: "Procesando", color: "bg-blue-500/10 text-blue-600" },
  shipped: { label: "Enviado", color: "bg-purple-500/10 text-purple-600" },
  delivered: { label: "Entregado", color: "bg-green-500/10 text-green-600" },
  cancelled: { label: "Cancelado", color: "bg-red-500/10 text-red-600" },
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Order.list("-created_date", 50).then((data) => {
      setOrders(data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <h1 className="font-space text-3xl sm:text-4xl font-bold tracking-tight">
          Mis Pedidos
        </h1>
        <p className="text-muted-foreground mt-2">Historial completo de tus compras</p>
      </motion.div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 rounded-2xl bg-secondary animate-pulse" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-24 space-y-4"
        >
          <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto">
            <ShoppingBag className="w-10 h-10 text-muted-foreground" />
          </div>
          <p className="text-xl font-medium">Aún no tienes pedidos</p>
          <p className="text-muted-foreground">Cuando realices una compra aparecerá aquí.</p>
          <Link to="/productos" className="inline-block mt-4 text-primary font-medium hover:underline">
            Explorar productos →
          </Link>
        </motion.div>
      ) : (
        <div className="space-y-4">
          {orders.map((order, idx) => {
            const status = statusConfig[order.status] || statusConfig.processing;
            const itemCount = order.items?.reduce((s, i) => s + (i.quantity || 1), 0) || 0;
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-card rounded-2xl border border-border/50 p-6 hover:shadow-lg hover:shadow-primary/5 transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Package className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-3 flex-wrap">
                        <p className="font-semibold font-space">
                          Pedido #{order.id.slice(-8).toUpperCase()}
                        </p>
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${status.color}`}>
                          {status.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {new Date(order.created_date).toLocaleDateString("es-AR", {
                            day: "2-digit", month: "short", year: "numeric",
                          })}
                        </span>
                        <span>{itemCount} producto{itemCount !== 1 ? "s" : ""}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right sm:text-left">
                    <p className="text-2xl font-bold font-space">{formatPrice(order.total)}</p>
                  </div>
                </div>

                {/* Items preview */}
                {order.items?.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border/50">
                    <div className="flex gap-3 overflow-x-auto pb-1">
                      {order.items.slice(0, 4).map((item, i) => (
                        <div key={i} className="flex-shrink-0">
                          <img
                            src={item.images?.[0]}
                            alt={item.name}
                            className="w-14 h-14 rounded-xl object-cover bg-secondary"
                          />
                        </div>
                      ))}
                      {order.items.length > 4 && (
                        <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center text-sm font-medium text-muted-foreground flex-shrink-0">
                          +{order.items.length - 4}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
