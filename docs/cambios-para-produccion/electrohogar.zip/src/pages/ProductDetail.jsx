import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Star,
  ShoppingCart,
  Heart,
  Truck,
  Shield,
  RotateCcw,
  Minus,
  Plus,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { getProductById, formatPrice, products } from "../lib/storeData";
import ImageGallery from "../components/products/ImageGallery";
import ReviewsSection from "../components/products/ReviewsSection";
import ProductCard from "../components/products/ProductCard";
import useCart from "../hooks/useCart";
import { useToast } from "@/components/ui/use-toast";
import { trackView } from "../lib/browsingHistoryStore";

export default function ProductDetail() {
  const { id } = useParams();
  const product = getProductById(id);
  const [quantity, setQuantity] = useState(1);
  const [liked, setLiked] = useState(false);
  const { addToCart } = useCart();
  const { toast } = useToast();

  useEffect(() => {
    if (product) trackView(product.id);
  }, [product?.id]);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-xl text-muted-foreground">Producto no encontrado</p>
        <Link to="/productos" className="text-primary mt-4 inline-block hover:underline">
          Volver a productos
        </Link>
      </div>
    );
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast({
      title: "Agregado al carrito",
      description: `${quantity}x ${product.name}`,
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-5 lg:py-12">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-foreground transition-colors">Inicio</Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <Link to="/productos" className="hover:text-foreground transition-colors">Productos</Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <Link
          to={`/productos?category=${product.category}`}
          className="hover:text-foreground transition-colors capitalize"
        >
          {product.category}
        </Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-foreground truncate max-w-48">{product.name}</span>
      </nav>

      {/* Product main section */}
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-16">
        {/* Images */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
        >
          <ImageGallery images={product.images} name={product.name} />
        </motion.div>

        {/* Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="space-y-6"
        >
          {/* Brand + Badge */}
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground uppercase tracking-wide font-medium">
              {product.brand}
            </span>
            {product.badge && (
              <span className="px-2.5 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-lg">
                {product.badge}
              </span>
            )}
          </div>

          <h1 className="font-space text-xl sm:text-3xl lg:text-4xl font-bold tracking-tight">
            {product.name}
          </h1>

          {/* Rating */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(product.rating)
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-border"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm font-medium">{product.rating}</span>
            <span className="text-sm text-muted-foreground">
              ({product.reviews.toLocaleString()} reseñas)
            </span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 pb-6 border-b border-border/50">
            <span className="font-space text-3xl sm:text-4xl font-bold">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <>
                <span className="text-lg text-muted-foreground line-through">
                  {formatPrice(product.originalPrice)}
                </span>
                <span className="px-2.5 py-1 bg-green-500/10 text-green-600 text-sm font-semibold rounded-lg">
                  -{discount}% OFF
                </span>
              </>
            )}
          </div>

          {/* Description */}
          <p className="text-muted-foreground leading-relaxed">
            {product.description}
          </p>

          {/* Specs */}
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(product.specs).map(([key, value]) => (
              <div
                key={key}
                className="px-4 py-3 rounded-xl bg-secondary/50 border border-border/30"
              >
                <p className="text-xs text-muted-foreground capitalize">{key}</p>
                <p className="font-medium text-sm mt-0.5">{value}</p>
              </div>
            ))}
          </div>

          {/* Quantity + Add to cart */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <div className="flex items-center border border-border rounded-xl overflow-hidden">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-12 h-12 flex items-center justify-center hover:bg-secondary transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-14 text-center font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-12 h-12 flex items-center justify-center hover:bg-secondary transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <Button
              onClick={handleAddToCart}
              size="lg"
              className="flex-1 h-12 text-base rounded-xl font-semibold gap-2"
            >
              <ShoppingCart className="w-5 h-5" />
              Agregar al Carrito
            </Button>

            <Button
              variant="outline"
              size="lg"
              onClick={() => setLiked(!liked)}
              className="h-12 w-12 rounded-xl p-0 flex-shrink-0 hidden sm:flex"
            >
              <Heart
                className={`w-5 h-5 ${
                  liked ? "fill-red-500 text-red-500" : ""
                }`}
              />
            </Button>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-border/50">
            {[
              { icon: Truck, label: "Envío Gratis", sub: "A todo el país" },
              { icon: Shield, label: "Garantía", sub: "2 años oficial" },
              { icon: RotateCcw, label: "Devolución", sub: "30 días" },
            ].map(({ icon: Icon, label, sub }) => (
              <div
                key={label}
                className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">{label}</p>
                  <p className="text-xs text-muted-foreground">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Reviews */}
      <ReviewsSection productId={product.id} />

      {/* Related products */}
      {related.length > 0 && (
        <section className="mt-20">
          <h2 className="font-space text-2xl font-bold mb-8">
            Productos Relacionados
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
