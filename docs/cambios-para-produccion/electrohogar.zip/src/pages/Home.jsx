import PromoBanner from "../components/products/PromoBanner";
import FeaturedProducts from "../components/home/FeaturedProducts";
import CategoryExplorer from "../components/home/CategoryExplorer";
import RecommendationsSection from "../components/recommendations/RecommendationsSection";

export default function Home() {
  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <PromoBanner />
      </div>
      <FeaturedProducts />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RecommendationsSection />
      </div>
      <CategoryExplorer />
    </div>
  );
}
